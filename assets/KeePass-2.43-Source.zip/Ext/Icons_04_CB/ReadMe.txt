Christopher Bolin has made these nice icons for KeePass.
Many thanks to him!
